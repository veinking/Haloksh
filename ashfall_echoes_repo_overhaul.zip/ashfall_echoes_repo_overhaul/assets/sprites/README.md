Place sprite sheets here. Current browser build uses CSS placeholder sprites.
